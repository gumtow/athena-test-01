import React from 'react';
import './App.css';
import data from './StudentTable.json';

function App() {



  const newData = data.map((data) => {
    let avg = Math.round((data.scores.test1 + data.scores.test2 + data.scores.test3) / 3);
    return({... data, avg});
  });



  console.log(data);


  return (
    <div className="App">
     <table>
       <thead>
         <tr>
           <td>Student Name</td>
           <td>Age</td>
           <td>Test1</td>
           <td>Test2</td>
           <td>Test3</td>
           <td>Avg</td>
           <td>Standing</td>
         </tr>
       </thead>
       <tbody>
         {newData.map((data, i) => {
           


           return(
             <tr key={i}>
               <td>{data.lastName}, {data.firstName}</td>
               <td>{data.age}</td>
               <td>{data.scores.test1}</td>
               <td>{data.scores.test2}</td>
               <td>{data.scores.test3}</td>
               <td>{data.avg}</td>
               <td></td>
             </tr>
           )
         })}
       </tbody>
     </table>

    </div>
  );
}

export default App;
